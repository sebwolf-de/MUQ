% Parallel utilities for the Matlab SUNDIALS interfaces
%
% Functions:
%
% mpirun     - runs parallel examples
% mpiruns    - runs the parallel example on a child MATLAB process
% mpistart   - lamboot and MPI_Init master (if required)


